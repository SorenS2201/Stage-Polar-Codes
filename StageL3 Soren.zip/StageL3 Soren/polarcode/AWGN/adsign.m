function [s] = adsign(a)
if a<0
    s = -1;
else
    s = +1;
end
end