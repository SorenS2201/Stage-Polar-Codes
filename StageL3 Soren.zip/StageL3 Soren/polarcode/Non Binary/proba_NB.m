function [p] = proba_NB(y,x,sigma2)
p = (1/sqrt(2*pi*sigma2))*exp((y-x).^2 /(2*sigma2));
end