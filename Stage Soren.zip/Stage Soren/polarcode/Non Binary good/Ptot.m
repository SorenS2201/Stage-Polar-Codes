function [P] = Ptot(x,y,sigma2)    %pour x€[-1;1]
S = 0.5*(proba_NB(y,-1,sigma2)+proba_NB(y,1,sigma2));
P = 0.5*proba_NB(y,x,sigma2)/S;
end