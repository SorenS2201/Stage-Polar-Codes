function [out] = g(x0,x1,u0)
n = size(x0,2);
out = -ones(1,n);
for i=1:n
    out(i) = x1(i) + ((-1)^u0(i))*x0(i);
end
end