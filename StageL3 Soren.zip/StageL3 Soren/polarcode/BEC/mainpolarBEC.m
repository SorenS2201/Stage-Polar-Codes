clear;
clc;

%%  Main variables
l = 10;
N = 2^l;
e = 0.3;    %taux d'effacement
R = 0.5;    %rendement

c = zeros(1,round(N*R));    %message que l'on veut envoyer
for k=1:round(N*R)
    c(k) = round(rand());
end

%%  Taux d'effacement polarisés
numbit = zeros(1,N);
polbit = zeros(1,N);
for i=1:N             %création le la list binaire des num de bit
    numbit(i) = i-1;
end

for k=1:N               %calcul du taux d'effacement de tous les
    btemp = numbit(k);  %sous-canaux polarisés
    etemp = e;
    for i=l-1:-1:0
        etemp = fctpolar(fix(btemp/(2^i)),etemp);
        btemp = rem(btemp,(2^i));
    end
    polbit(N-k+1) = etemp;
end

%%  Bits frozen Bits free
Ifree = zeros(1,size(c,2));
Ifrozen = zeros(1,N-size(c,2));                   %on part du princide que le msg ne sera
[sortedbit,idx] = sort(polbit); %jamais trop long pour le l choisi

% tiledlayout(1,2);
% nexttile
% plot(numbit,polbit,'.')
% nexttile
% plot(numbit,sortedbit,'.')

for i=1:N
    if (i<=N-size(c,2))
        Ifrozen(i) = idx(i);
    else
        Ifree(i-N+size(c,2)) = idx(i);
    end
end

%%  Construction du message
u = zeros(1,N); %codeword avec le message c "bien" placé
k = 1;
for i=1:N
    if ismember(i,Ifrozen)
        u(i) = 0;
    else
        u(i) = c(k);
        k = k+1;
    end
end

%%  Polarisation du message
G0 = [1 0;
      1 1];
G = G0;
for k=1:l-1
    G = kron(G0,G);
end
v = rem(u*G,2);

%%  Passage dans le channel : BEC
r = zeros(1,N); %mot reçu
Ne = 0;
for k=1:N
    if (rand()<=e)
        r(k) = -1; %ce bit est effacé
        Ne = Ne+1;
    else
        r(k) = v(k);
    end
end

%%  SC decoding recurssive way
L = -ones(1,N);
for i=1:N
    L(i) = LLRBEC(r(i));
end
v_decoded = node_decode(l,1,L,Ifrozen);
y_decoded = rem(v_decoded*G,2);

%% Results
Nefinal = 0;
c_decoded = -ones(1,size(c,2));
k = 1;
for i=1:N
    if ismember(i,Ifree)
        c_decoded(k) = y_decoded(i);
        if c_decoded(k)~=c(k)
            Nefinal = Nefinal+1;
        end
        k = k+1;
    end
end


disp('message envoyé :');
disp(c);
disp('message retrouvé :');
disp(c_decoded);

fprintf("On commet %i erreurs avec %i erreurs initiales\n",Nefinal,Ne);



