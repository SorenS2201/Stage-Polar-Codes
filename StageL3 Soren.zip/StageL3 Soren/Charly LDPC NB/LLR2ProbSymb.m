function [ProbaVect]=LLR2ProbSymb(llr,m, BinaryMapping)

Nsymb=floor(numel(llr)/m);
ProbaVect=exp((1-BinaryMapping)*reshape(llr,m,Nsymb));
%ProbaVect(ProbaVect>10^300) = 10^300;
Z=sum(ProbaVect);%Normalization factor
ProbaVect=ProbaVect*diag(1./Z);
end