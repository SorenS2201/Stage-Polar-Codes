function [ LLRs ] = LLRSoftDemapper(SymbApp, Apriori, BinaryTable)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[M,N]=size(SymbApp);
LLRs=zeros(log2(M),N);
LLRs=log((1-BinaryTable')*(SymbApp.*Apriori))-log(BinaryTable'*(SymbApp.*Apriori));
%LLRs(LLRs < -10^300) = -10^300;
%LLRs(LLRs > 10^300) = 10^300;
end

