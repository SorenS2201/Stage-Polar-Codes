function [P3] = f(P1,P2)
global alpha beta MULGF DIVGF
n = size(P2,2);

t1 = zeros(1,n);
t2 = zeros(1,n);

pos = (0:n-1);
P3 = zeros(size(P2,1),n);

for k=1:n
    t1(k) = DIVGF(pos(k)+1,beta+1);
    t2(k) = MULGF(t1(k)+1,alpha+1);
end

for i=1:size(P3,1)
    P3(i,:) = opeH(P1(i,:),P2(i,t2+1),n);
    P3(i,:) = normalizationfact(P3(i,:))*P3(i,:);
end

end