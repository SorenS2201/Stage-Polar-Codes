clc;
clear;

f = waitbar(0,'0%','Name','Calculating...');
nbe = 100;
emin=0; emax=1; pas=0.01;
l = 10;
N = 2^l;
R = 0.5;

c = zeros(1,round(N*R));
for k=1:round(N*R)
    c(k) = round(rand());
end

iter = 1+ round((emax-emin)/pas);
Le = zeros(1,iter);
BER = zeros(1,iter);
error_temp = zeros(1,nbe);

G0 = [1 0;
      1 1];
numbit = zeros(1,N);
polbit = zeros(1,N);
for i=1:N             
    numbit(i) = i-1;
end


beri = 1;
steps = iter*nbe;
step = 0;
for e=emin:pas:emax
    Le(beri) = e;

    for k=1:N               %calcul du taux d'effacement de tous les
        btemp = numbit(k);  %sous-canaux polarisés
        etemp = e;
        for i=l-1:-1:0
            etemp = fctpolar(fix(btemp/(2^i)),etemp);
            btemp = rem(btemp,(2^i));
        end
        polbit(N-k+1) = etemp;
    end    
    Ifree = zeros(1,size(c,2));
    Ifrozen = zeros(1,N-size(c,2));
    [etemp,idx] = sort(polbit);
    for i=1:N
        if (i<=N-size(c,2))
            Ifrozen(i) = idx(i);
        else
            Ifree(i-N+size(c,2)) = idx(i);
        end
    end
    u = zeros(1,N); %codeword avec le message c "bien" placé
    k = 1;
    for i=1:N
        if ismember(i,Ifrozen)
            u(i) = 0;
        else
            u(i) = c(k);
            k = k+1;
        end
    end
    G = G0;
    for k=1:l-1
        G = kron(G0,G);
    end
    v = rem(u*G,2);


    for n=1:nbe
        step = (beri-1)*nbe + n;
        waitbar(step/steps,f,sprintf('%5.1f%%       %i/%i achieved',round(100*step/steps,1),step,steps));
        error_temp(n) = polar_courbes(l,e,v,Ifree,Ifrozen,G,R,c);
    end
    BER(beri) = mean(error_temp)/round(R*N);
    beri = beri+1;
end

plot(Le,BER);%,'DisplayName',['e=' num2str(e)])
hold on


%%  Plotting
%plot(Le,BER);
title('Perfect - BEC - R=0.5');
xlabel('e');
ylabel('BER');
legend('Location','southeast');
hold off
saveas(gcf,'Perfect-BEC-R=0.5_#?.png')