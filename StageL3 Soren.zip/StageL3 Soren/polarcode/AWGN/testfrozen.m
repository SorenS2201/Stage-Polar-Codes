load Ifrozen.mat
load Ifrozencomputed.mat

N = 0;
n = numel(Ifrozen);
for k=1:n
    if ismember(Ifrozen(k),Ifrozencomputed)
        N = N + 1;
    end
end
