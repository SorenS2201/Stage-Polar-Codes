clc;
clear;

%%  Loading
nbc = 6;
path = 'Courbes compa/';
LSNR = (-1:0.1:2);
Lname = ['NB r=2';'NB r=4';'NB r=5';'NB r=6';'NB r=8';'B     '];
LBER = zeros(nbc,numel(LSNR));

load(strcat(path,'[-1:2]_NBPC2_SNR=1.mat'));
LBER(1,:) = BER;

load(strcat(path,'[-1:2]_NBPC4_SNR=1.mat'));
LBER(2,:) = BER;

load(strcat(path,'[-1:2]_NBPC5_SNR=1.mat'));
LBER(3,:) = BER;

load(strcat(path,'[-1:2]_NBPC6_SNR=1.mat'));
LBER(4,:) = BER;

load(strcat(path,'[-1:2]_NBPC8_SNR=1.mat'));
LBER(5,:) = BER;

load(strcat(path,'[-1:2]_PC_SNR=1.mat'));
LBER(6,:) = BER;


%%  Plotting
for itemp=1:nbc
    semilogy(LSNR,LBER(itemp,:),'DisplayName',Lname(itemp,:));
    hold on
end
title('AWGN - NBPC');
xlabel('SNR (dB)');
ylabel('BER');
legend('Location','southwest');
grid on
hold off
%saveas(gcf,'HD-AWGN-NBPC_#2.png')