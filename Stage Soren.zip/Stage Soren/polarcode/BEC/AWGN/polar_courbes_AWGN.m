function [Nefinal] = polar_courbes_AWGN(l,e,v,Ifree,Ifrozen,G,R,c)
N = 2^l;


%%  BPSK
v = -2*v +1;

%%  Passage dans le channel : BEC, AWGN
r = v + e*randn(1,N);

%%  SC decoding recurssive way
L = -ones(1,N);
for i=1:N
    L(i) = LLRBEC_AWGN(r(i),e);
end
v_decoded = node_decode(l,1,L,Ifrozen);
y_decoded = rem(v_decoded*G,2);

%% Results
c_decoded = y_decoded(sort(Ifree));
Nefinal = sum(c~=c_decoded);
end