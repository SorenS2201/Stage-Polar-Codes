T=0.01; %s
t=linspace(0,T,1000);
M=4;
f0=M/T;
A=sqrt(2/T);

s0=A*cos(2*pi*f0*t);
s1=-A*cos(2*pi*f0*t);

plot(t,s0,t,s1);


