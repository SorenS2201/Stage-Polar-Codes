function [VtoC] = VNupdate_Proba(GF,Channel, VNdegree,CtoVintlv,dvClass,Nedges)
%VNupdate_Proba VN update for Non Binary LDPC codes using FHT
%   VN update for probability Domain
%   -GF: Field order
%   -Channel: Vector of Channel Likelihood probability Vector, binary label
%   indexing
%   -VNdegree: vector of VN degrees
%   -CtoCintlv: CtoV Probability messages ordered from the VN perspective;
%   Binary Indexing;
%   -dvClass: Degree Class for each edge
%   -Number of edges
%
VtoC=zeros(GF,Nedges);
dv=unique(VNdegree);
 for ii=dv
     %vectorized product for all CNs of same degree in the transform
        %domain
        VtoCtmp=reshape(CtoVintlv(:,dvClass==ii),GF,ii,numel(dvClass(dvClass==ii))/ii);
        if ii>1
        %Loop is needed since incoming messages can be zero
            CtoVtmp=zeros(GF,ii,numel(dvClass(dvClass==ii))/ii);
            for kk=1:ii
              CtoVtmp(:,kk,:)=prod(VtoCtmp(:,(1:ii)~=kk,:),[2]);
            end
            %CtoVtmp=reshape(CtoVtmp(:),GF,numel(CtoVFtmp)/GF);
            Channeltmp=kron(Channel(:,VNdegree==ii),ones(1,ii));
            VtoC(:,dvClass==ii)=reshape(CtoVtmp(:),GF,numel(CtoVtmp)/GF).*Channeltmp;%
        else
            VtoC(:,dvClass==ii)=Channel(:,VNdegree==ii);%
        end
 end
 NormValues=1./sum(VtoC);
 NormMat=speye(numel(NormValues),numel(NormValues));
 NormMat(NormMat~=0)=NormValues;
 VtoC=VtoC*NormMat;%normalization
end