function [newe] = fctpolar(action,e)
if (action==0)
    newe = 2*e-e^2;
end
if (action==1)
    newe = e^2;
end
end