clear;
clc;

%%  Main variables
l = 10;
N = 2^l;
e = 0.5;    %taux d'effacement
R = 0.5;    %rendement

c = zeros(1,round(N*R));    %message que l'on veut envoyer
for k=1:round(N*R)
    c(k) = round(rand());
end

%%  Taux d'effacement polarisés
numbit = zeros(1,N);
polbit = zeros(1,N);
for i=1:N             %création le la list binaire des num de bit
    numbit(i) = i-1;
end

for k=1:N               %calcul du taux d'effacement de tous les
    btemp = numbit(k);  %sous-canaux polarisés
    etemp = e;
    for i=l-1:-1:0
        etemp = fctpolar(fix(btemp/(2^i)),etemp);
        btemp = rem(btemp,(2^i));
    end
    polbit(N-k+1) = etemp;
end

%%  Bits frozen Bits free
Ifree = zeros(1,size(c,2));
Ifrozen = zeros(1,N-size(c,2));                   %on part du princide que le msg ne sera
Bfrozen = zeros(1,N-size(c,2));
Bfree = zeros(1,N-size(c,2));
[sortedbit,idx] = sort(polbit); %jamais trop long pour le l choisi

% tiledlayout(1,2);
% nexttile
% plot(numbit,polbit,'.')
% nexttile
% plot(numbit,sortedbit,'.')

for i=1:N
    if (i<=N-size(c,2))
        Ifrozen(i) = idx(i);
        Bfrozen(i) = sortedbit(i);
    else
        Ifree(i-N+size(c,2)) = idx(i);
        Bfree(i-N+size(c,2)) = sortedbit(i);
    end
end

%%  Plotting
plot(Ifrozen,Bfrozen,'b.','DisplayName','Bits Frozen');
hold on
plot(Ifree,Bfree,'r.','DisplayName','Bits Free');
hold off
title('Polarisation 1024bits R=0.5 e=0.5');
legend