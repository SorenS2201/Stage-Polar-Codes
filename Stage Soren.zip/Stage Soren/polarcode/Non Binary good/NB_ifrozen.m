function [Ifrozen] = NB_ifrozen(Ns,r,R,SNR_dB,F)

global ADDGF MULGF

%%  Main variables
SNR = 10^(SNR_dB/10);
sigma2 = 1/(2*R*SNR);    %écart-type

q = 2^r;

N = r*Ns;


nbt = 1000;

%%  Galois Field operations
symb = (0:q-1);


%%  Transmission
c = -ones(1,N/r);
x = -ones(1,N);
Pc = zeros(N/r,q);  %ligne=signe et colonne PMF
u_decoded = zeros(1,N/r);

Ifrozen = [];
error_count = zeros(1,N/r);

for tries=1:nbt
    u = randsrc(1,Ns,symb);
    u(Ifrozen+1) = zeros(1,numel(Ifrozen));

    for itemp=1:Ns
        S = 0;              %c=u*F
        for ktemp=1:Ns
            S = ADDGF(S+1,MULGF(u(ktemp)+1,F(ktemp,itemp)+1)+1);
        end
        c(itemp) = S;
    
        atemp = de2bi(S,r,'left-msb');  %Mapper
        x(r*(itemp-1)+1:r*itemp) = atemp;
    end

    xBPSK = -2*x +1;    %BPSK

    y = xBPSK + sigma2*randn(1,N);  %AWGN

    for itemp=1:Ns
        for jtemp=1:q
            Mul = 1;
            btemp = de2bi(jtemp-1,r,'left-msb');
            for ktemp=1:r
                Mul = Mul *(1 - Ptot(1-2*btemp(ktemp),y((itemp-1)*r+ktemp),sigma2));
            end
            Pc(itemp,jtemp) = Mul;      %proba de c_decoded
        end
    end
    
    %Pc = radicalized(Pc);
    c_decoded = node_decode_NB(log2(Ns),1,Pc,Ifrozen);
    

    for itemp=1:N/r
        S = 0;              %u=c*F
        for ktemp=1:N/r
            S = ADDGF(S+1,MULGF(c_decoded(ktemp)+1,F(ktemp,itemp)+1)+1);
        end
        u_decoded(itemp) = S;
    end

    error_count = error_count + (u_decoded~=u);

    
end

percerror = 100*error_count/tries;

[~,idxerror] = sort(percerror);
fidx = flip(idxerror);
Ifrozen = fidx(1:round(R*Ns));
end