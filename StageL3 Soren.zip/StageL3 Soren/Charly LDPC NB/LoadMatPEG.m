function [ Proto ] = LoadMatPEG(name)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
MatPEG=load(name);

n=MatPEG(1,1);
m=MatPEG(1,2);

%Proto=zeros(m,n);
Proto=spalloc(m,n,numel(MatPEG(2:end,:)));
for ii=2:m+1
   index=find(MatPEG(ii,:)>0);
   Proto(ii-1,MatPEG(ii,index))=1;
end

