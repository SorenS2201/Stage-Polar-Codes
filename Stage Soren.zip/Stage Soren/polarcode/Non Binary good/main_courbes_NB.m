clc;
clear;

global alpha beta ADDGF MULGF DIVGF GFPerm DectoGF
f = waitbar(0,'0%','Name','Calculating...');

%%  Param Simu
nbe = 1000;
SNRmin=-1; SNRmax=2; pas=0.1;

r = 7;
R = 0.5;
Ns = 2^7;
q = 2^r;
N = r*Ns;

%%  Param Plot
iter = 1+ round((SNRmax-SNRmin)/pas);
Le = zeros(1,iter);
BER = zeros(1,iter);
error_temp = zeros(1,nbe);

%%  GF operands
alpha = 1;
beta = 1;

TablePath='Tables/';

GF=q;
ADDGF=load(strcat(TablePath,'ADDGF',int2str(GF)));
DIVGF=load(strcat(TablePath,'DIVGF',int2str(GF)));
MULGF=load(strcat(TablePath,'MULGF',int2str(GF)));
BINGF=load(strcat(TablePath,'BINGF',int2str(GF)));

symb = (0:q-1);

GFPerm=bi2de(BINGF,'left-msb')+1;
DectoGF=(0:GF-1);
DectoGF(GFPerm)=DectoGF;%Permutattion ok.

F0 = [1 0;
      alpha beta];
F = F0;

for k=1:log2(Ns)-1
    aFtemp = zeros(2^k);
    bFtemp = zeros(2^k);

    for itemp=1:2^k
        for jtemp=1:2^k
            aFtemp(itemp,jtemp) = MULGF(alpha+1,F(itemp,jtemp)+1);
            bFtemp(itemp,jtemp) = MULGF(beta+1,F(itemp,jtemp)+1);
        end
    end
    F = [F zeros(2^k);aFtemp bFtemp];
end

%%  Simu Variable
c = -ones(1,Ns);
x = -ones(1,N);
x_decoded = -ones(1,N);
Pc = zeros(Ns,q);  %ligne=signe et colonne PMF
u_decoded = zeros(1,Ns);
c_decoded = zeros(1,Ns);


steps = iter*nbe;
step = 0;

Ifrozen = NB_ifrozen(Ns,r,R,1,F);

%%  Simu

beri = 1;
for SNR_dB=SNRmin:pas:SNRmax
    Le(beri) = SNR_dB;
    SNR = 10^(SNR_dB/10);
    sigma2 = 1/(2*R*SNR);    %écart-type

    for n=1:nbe
        step = (beri-1)*nbe + n;

        u = randsrc(1,Ns,symb);
        u(Ifrozen) = zeros(1,numel(Ifrozen));
    
        for itemp=1:Ns
            S = 0;              %c=u*F
            for ktemp=1:Ns
                S = ADDGF(S+1,MULGF(u(ktemp)+1,F(ktemp,itemp)+1)+1);
            end
            c(itemp) = S;
        
            atemp = de2bi(S,r,'left-msb');  %Mapper
            x(r*(itemp-1)+1:r*itemp) = atemp;
        end
    
        xBPSK = -2*x +1;    %BPSK
    
        y = xBPSK + sigma2*randn(1,N);  %AWGN
    
        for itemp=1:Ns
            for jtemp=1:q
                Mul = 1;
                btemp = de2bi(jtemp-1,r,'left-msb');
                for ktemp=1:r
                    Mul = Mul *(1 - Ptot(1-2*btemp(ktemp),y((itemp-1)*r+ktemp),sigma2));
                end
                Pc(itemp,jtemp) = Mul;      %proba de c_decoded
            end
        end

        c_decoded = node_decode_NB(log2(Ns),1,Pc,Ifrozen);
        
        for itemp=1:Ns
            atemp = de2bi(c_decoded(itemp),r,'left-msb');
            x_decoded(r*(itemp-1)+1:r*itemp) = atemp;
        end

%         for itemp=1:N/r
%             S = 0;              %u=c*F
%             for ktemp=1:N/r
%                 S = ADDGF(S+1,MULGF(c_decoded(ktemp)+1,F(ktemp,itemp)+1)+1);
%             end
%             u_decoded(itemp) = S;
%         end
    
        error_temp(n) = sum(x_decoded~=x);
        
        waitbar(step/steps,f,sprintf('%5.1f%%',round(100*step/steps,1)));


    end
    BER(beri) = mean(error_temp)/N;
    beri = beri+1;
end



%%  Plotting
semilogy(Le,BER);%,'DisplayName',['e=' num2str(e)])
hold on

title('NBPC-AWGN - r=3 - Ns=32 - R=0.5');
xlabel('SNR (dB)');
ylabel('SER');
legend('Location','southeast');
grid on
hold off
%saveas(gcf,'NBPC-AWGN - r=3 - Ns=32 - R=0.5_#?.png')
%save('[-1:2]_NBPC7_SNR=1.mat','BER')