r = 3;
q = 2^r;

GFf = zeros(q+1,q+1);
GFp = zeros(q+1,q+1);

list = zeros(1,q);
for k=1:q   list(k)=k-1;  end

GFp(1,:) = [0 list];
GFf(1,:) = [0 list];
GFp(:,1) = [0 list];
GFf(:,1) = [0 list];

for i=2:q+1
    for j=2:q+1
        GFp(i,j) = rem((i-2)+(j-2),q);
        GFf(i,j) = rem((i-2)*(j-2),q);
    end
end