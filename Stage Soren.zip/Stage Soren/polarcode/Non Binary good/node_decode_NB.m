function [U] = node_decode_NB(etage,etape,Pi,Ifrozen)
global alpha beta ADDGF MULGF DIVGF DectoGF
n = size(Pi,1);

% disp([etage etape]);
% disp(Pi);

if etage==0 %on a leaf
    if ismember(etape,Ifrozen)
        U = 0;
    else
        [mp,idx] = sort(Pi);
        U = idx(numel(idx))-1;    %on prend le plus probable
    end

else        %on any other node
    
    Pf = f(Pi(1:n/2,:),Pi(n/2 +1:n,:));
    U2 = node_decode_NB(etage-1,2*(etape-1)+1,Pf,Ifrozen);    %on active la node de gauche
    
    Pg = g(Pi(1:n/2,:),Pi(n/2 +1:n,:),U2);
    U3 = node_decode_NB(etage-1,2*(etape-1)+2,Pg,Ifrozen);    %on active la node de droite
    
    Uf1 = zeros(1,n/2);
    Uf2 = zeros(1,n/2);
    for k=1:n/2
        Uf1(k) = ADDGF(U2(k)+1,DIVGF(U3(k)+1,alpha+1)+1);
        Uf2(k) = DIVGF(U3(k)+1,beta+1);
    end

    U = [Uf1 Uf2];
end
% disp(U);
end