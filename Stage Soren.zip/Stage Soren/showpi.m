N=10000;
nt=100;
X=zeros(N,nt);
Y=zeros(N,nt);
guessPi=0;

for j=1:nt
    c=0;
    for i=1:N
        X(i,j)=rand(1);
        Y(i,j)=rand(1);
        if (X(i,j)^2+Y(i,j)^2 <= 1)
            c=c+1;
        end
    end
    guessPi=guessPi+4*c/N;
end
guessPi=guessPi/nt;
% t=linspace(0,pi/2,1000);
% Xc=cos(t);
% Yc=sin(t);
% 
% plot(X,Y,".b",Xc,Yc,"r");
% xlim([-0.1,1.1]);
% ylim([-0.1,1.1]);
% 
% disp(guessPi);