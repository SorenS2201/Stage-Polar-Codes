function [out] = f(x0,x1)
n = size(x0,2);
out = -ones(1,n);
for i=1:n
    out(i) = adsign(x0(i))*adsign(x1(i))*min([abs(x0(i)),abs(x1(i))]);
end
end