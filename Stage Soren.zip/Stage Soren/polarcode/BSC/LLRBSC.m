function [z] = LLRBSC(y,p)
if (y==0)
    z = log((1-p)/p);

elseif (y==1)
    z = log(p/(1-p));
end

end