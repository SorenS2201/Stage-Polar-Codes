function [Nefinal] = polar_courbes(l,e,v,Ifree,Ifrozen,G,R,c)
N = 2^l;


%%  Passage dans le channel : BEC
r = zeros(1,N); %mot reçu
Ne = 0;
for k=1:N
    if (rand()<=e)
        r(k) = -1; %ce bit est effacé
        Ne = Ne+1;
    else
        r(k) = v(k);
    end
end

%%  SC decoding recurssive way
L = -ones(1,N);
for i=1:N
    L(i) = LLRBEC(r(i));
end
v_decoded = node_decode(l,1,L,Ifrozen);
y_decoded = rem(v_decoded*G,2);
%% Results
Nefinal = 0;
c_decoded = -ones(1,round(R*N));
k = 1;
for i=1:N
    if ismember(i,Ifree)
        c_decoded(k) = y_decoded(i);
        if c_decoded(k)~=c(k)
            Nefinal = Nefinal+1;
        end
        k = k+1;
    end
end
end