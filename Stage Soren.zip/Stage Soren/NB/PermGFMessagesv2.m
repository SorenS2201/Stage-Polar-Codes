function [ExpPerm] = PermGFMessagesv2(GF,coeff)
%PermGFMessagesv2
%   Permutation of messages for VN to CN upadtes:
%   generation of the global index permutation form the VN perspective when
%   GF ordering is used. This function generate the permutation index in
%   the GF ordering once for a while,. ie. at the program init.
%   Note GF ordering can be done previously by simple row index switching.
%
%  Input Parameters:
%  ===================
%   -GF: GF order
%   -Coeff:  GF coeff from VN perspective with GF (power) ordering.
%
%  Output Parameters:
%  ===================
%   -ExpPerm: Permutation indexes for VN perspectives. VN messages follow
%   GF ordering (power of GF primitive element)
%

%init
    ExpPerm=zeros(GF,numel(coeff));%%Zero coeff is always zero !

%'0' coeff
    for nn=1:numel(coeff)%%Circular permutation
        ExpPerm(2:end,nn)=mod((coeff(nn)-1:(coeff(nn)-1)+(GF-2)),GF-1)+1;%1<=Coeff<=GF-1, permutation of index vectorwise.
        ExpPerm(:,nn)=ExpPerm(:,nn)+(nn-1)*(GF)+1;%absolute indexing for the entire VN messages matrices seen as a collection of VN vector
    end
    ExpPerm=ExpPerm(:);
end

