clc
clear


n = 10;

absc = zeros(4,n);
ordo = zeros(4,n);

for k=1:n
    ordo(1,k) = 1;
    ordo(2,k) = 2;
    ordo(3,k) = 3;
    ordo(4,k) = 4;
end
for i=1:4
    absc(i,:) = (1:n);
end

plot(absc',ordo')