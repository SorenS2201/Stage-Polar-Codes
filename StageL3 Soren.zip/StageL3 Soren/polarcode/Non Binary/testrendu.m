r=2;
Pc = zeros(2,4);
sigma2 = 0.8;;
y = [-0.73 1.64 -0.42 -1.39];

for itemp=1:2
    for jtemp=1:4
        Mul = 1;
        btemp = de2bi(jtemp-1,r,'left-msb');
        for ktemp=1:r
            Mul = Mul *(1 - Ptot(1-2*btemp(ktemp),y((itemp-1)*r+ktemp),sigma2));
        end
        Pc(itemp,jtemp) = Mul;      %proba de c_decoded
    end
end