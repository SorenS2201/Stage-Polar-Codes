function [H] = opeH(A,B,q)
global GFPerm DectoGF

A2 = fwht(A(DectoGF+1),q,'hadamard');
B2 = fwht(B(DectoGF+1),q,'hadamard');

H = fwht(A2.*B2,q,'hadamard');
H = H(GFPerm);
end