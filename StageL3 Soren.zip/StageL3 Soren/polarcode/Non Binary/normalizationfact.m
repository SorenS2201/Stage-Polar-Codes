function [c] = normalizationfact(L)

S = sum(L);
c = 1/S;

end