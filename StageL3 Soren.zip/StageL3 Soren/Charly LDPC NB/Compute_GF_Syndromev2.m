function [Status] = Compute_GF_Syndromev2(codeword,K,Hrows,Hcols,Hcoeffs,GF,GFtodec,BINGF,ADDGF,MULGF,DIVGF)
% Encoding for NB LDPC over Galois field of order GF=2^Q;
%   Encoding is done assuming directly encodable Parity CHeck Matrix
% 
%   Input parameters
%   ===============
%   -codeword: codeword in decimal using natural binary ordering (Left MSB);
%   -H: non binary PCMwith non binary coeff in gf order
%   -GF: Field Order
%   -GFtoDec: table for decimal correspondance for GF symbols ordererd in
%   the power domain
%   -BINGF: Binary representation of GF symbols, GF ordering
%   -ADDGF, MULGF and DIVGF: lookup table for GF operations, indexed using
%   power of prime element.

%Initialization
%Initialization
Q=log2(GF);
N=numel(codeword);
M=N-K;
%Encoding
GFPerm=bi2de(BINGF,'left-msb')+1;
DectoGF=(0:GF-1);
DectoGF(GFPerm)=DectoGF;
Syndrome=zeros(1,M);
CodedSymb=DectoGF(codeword+1);%Decimal to GF
ii=1;
for m=1:M
     while ((ii<(numel(Hrows)+1)) && (Hrows(ii)==(m)))
         Syndrome(m)=ADDGF(Syndrome(m)+1,MULGF(Hcoeffs(ii)+1,CodedSymb(Hcols(ii))+1)+1);
        ii=ii+1;  
     end
       
end
Syndrome=GFtodec(Syndrome+1);
Status=nnz(Syndrome);
end