function [out] = f(x0,x1)
n = size(x0,2);
out = -ones(1,n);
for i=1:n
    out(i) = 2*atanh(tanh(x0(i)/2)*tanh(x1(i)/2));
end
end