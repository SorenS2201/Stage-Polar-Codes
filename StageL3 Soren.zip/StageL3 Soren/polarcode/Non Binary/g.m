function [P3] = g(P1,P2,u)
global alpha beta ADDGF DIVGF
n = size(P2,2);
t1 = zeros(1,n);
t2 = zeros(1,n);
t3 = zeros(1,n);

pos = (0:n-1);
P3 = zeros(size(P2,1),n);

for j=1:size(P2,1)
    for k=1:n
        t1(k) = ADDGF(pos(k)+1,u(j)+1);
        t2(k) = DIVGF(t1(k)+1,alpha+1);
        t3(k) = DIVGF(pos(k)+1,beta+1);
    end

    P3(j,:) = P1(j,t2+1).*P2(j,t3+1);
    P3(j,:) = normalizationfact(P3(j,:))*P3(j,:);
end

end