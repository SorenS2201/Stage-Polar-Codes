clc;
clear;

f = waitbar(0,'0%','Name','Calculating...');
nbe = 1000;
emin=0.3; emax=0.7; pas=0.01;
l = 12;
N = 2^l;
R = 0.5;

lenc = round(N*R);
iter = 1+ round((emax-emin)/pas);
Le = zeros(1,iter);
BER = zeros(1,iter);
error_temp = zeros(1,nbe);

G0 = [1 0;
      1 1];
G = G0;
for k=1:l-1
    G = kron(G0,G);
end

numbit = zeros(1,N);
polbit = zeros(1,N);
for i=1:N             
    numbit(i) = i-1;
end

tdur = 0.01;
steps = iter*nbe;
step = 0;

beri = 1;
for e=emin:pas:emax
    Le(beri) = e;

    for k=1:N               %calcul du taux d'effacement de tous les
        btemp = numbit(k);  %sous-canaux polarisés
        etemp = e;
        for i=l-1:-1:0
            etemp = fctpolar(fix(btemp/(2^i)),etemp);
            btemp = rem(btemp,(2^i));
        end
        polbit(N-k+1) = etemp;
    end    
    Ifree = zeros(1,lenc);
    Ifrozen = zeros(1,N-lenc);
    [etemp,idx] = sort(polbit);
    for i=1:N
        if (i<=N-lenc)
            Ifrozen(i) = idx(i);
        else
            Ifree(i-N+lenc) = idx(i);
        end
    end
    u = zeros(1,N); %codeword avec le message c "bien" placé

    for n=1:nbe
        if n==1
            if e==emin
                ta = clock;
            end
        end
        step = (beri-1)*nbe + n;

        c = randsrc(1,lenc,[0,1]);      %on créé le msg
        
        u(sort(Ifree)) = c;               %on le place dans u

        v = rem(u*G,2);         %polarisation
        
        W = (steps-step)*tdur;
        heures = fix(W/3600);
        minutes = fix((W-heures*3600)/60);
        secondes = W-heures*3600-minutes*60;
        waitbar(step/steps,f,sprintf('%5.1f%%       %ih %im %is',round(100*step/steps,1),heures,minutes,round(secondes)));
        error_temp(n) = polar_courbes(l,e,v,Ifree,Ifrozen,G,R,c);

        if n==1
            if e==emin
                tb = clock;
                tdur = tb(6) - ta(6);
            end
        end
    end
    BER(beri) = mean(error_temp)/N;
    beri = beri+1;
end



%%  Plotting
semilogy(Le,BER);%,'DisplayName',['e=' num2str(e)])
hold on

title('Perfect - BEC - R=0.5');
xlabel('e');
ylabel('BER');
legend('Location','southeast');
grid on
hold off
saveas(gcf,'Perfect-BEC-R=0.5_#?.png')