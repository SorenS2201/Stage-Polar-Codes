clear;
clc;

%%  Main variables
l = 10;
N = 2^l;
SNR_dB = 3;
R = 0.5;    %rendement

SNR = 10^(SNR_dB/10);
sigma2 = 1/(2*R*SNR);    %écart-type


nbt = 10000;

%%  Calcul de F
F0 = [1 0;
      1 1];
F = F0;

for k=1:log2(N)-1
    F = [F zeros(2^k);F F];
end

%%  Transmission
c = -ones(1,N);
u_decoded = zeros(1,N);
c_decoded = zeros(1,N);

Ifrozen = [];
error_count = zeros(1,N);
L = -ones(1,N);

for tries=1:nbt
    u = randsrc(1,N,[0 1]);

    c = rem(u*F,2);

    xBPSK = -2*c +1;    %BPSK

    y = xBPSK + sigma2*randn(1,N);  %AWGN    
    
    for i=1:N
        L(i) = LLRBEC_AWGN(y(i),sigma2);
    end
    y_decoded = node_decode(l,1,L,Ifrozen);
    u_decoded = rem(y_decoded*F,2);


    error_count = error_count + (u_decoded~=u);

    percerror = 100*error_count/tries;

end

%% Plot
[errortried,idxtemp] = sort(percerror);
step = errortried(R*N);
Linf = find(percerror<=step);
Lsup = find(percerror>step);
absc = (0:N - 1);
plot(absc(Linf),percerror(Linf),'r+');
hold on
plot(absc(Lsup),percerror(Lsup),'b+');
hold on
title('Symbol polarization - SNR=1db');
xlabel('symbol id');
ylabel('error (%)');
xlim([-0.3 N-0.7]);
ylim([-1 101]);
grid on
hold off

Ifrozencomputed = absc(Linf);
%saveas(gcf,'Spolar-l=10-r=2-SNR=-3_#?.png')