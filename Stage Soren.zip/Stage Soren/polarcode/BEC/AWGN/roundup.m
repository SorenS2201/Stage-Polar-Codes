function [y] = roundup(x)
y = zeros(1,size(x,2));
for i=1:size(x,2)
    if x(i)<0
        y(i) = -1;
    else
        y(i) = +1;
    end
end
end