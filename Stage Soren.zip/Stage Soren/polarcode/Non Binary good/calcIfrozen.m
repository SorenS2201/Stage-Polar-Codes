clear;
clc;
global alpha beta ADDGF MULGF DIVGF GFPerm DectoGF

%%  Main variables
SNR_dB = 1;
R = 0.5;    %rendement

SNR = 10^(SNR_dB/10);
sigma2 = 1/(2*R*SNR);    %écart-type

AB = [1 1;
      3 1;
      6 2;
      14 2;
      26 2;
      38 1;
      105 1;
      204 2];

r = 4;  %longueur des vect de symbols, >1
q = 2^r;

Ns = 2^6;
N = r*Ns;

alpha = AB(r,1);
beta = AB(r,2);

TablePath='Tables/';
nbt = 100;

%%  Galois Field operations
GF=q;
ADDGF=load(strcat(TablePath,'ADDGF',int2str(GF)));
DIVGF=load(strcat(TablePath,'DIVGF',int2str(GF)));
MULGF=load(strcat(TablePath,'MULGF',int2str(GF)));
BINGF=load(strcat(TablePath,'BINGF',int2str(GF)));

symb = (0:q-1);

%%  Build required Graph Permutation and interleavers 
GFPerm=bi2de(BINGF,'left-msb')+1;
GFtodec=bi2de(BINGF,'left-msb');
DectoGF=(0:GF-1);
DectoGF(GFPerm)=DectoGF;%Permutattion ok.

%%  Calcul de F
F0 = [1 0;
      alpha beta];
F = F0;

for k=1:log2(Ns)-1
    aFtemp = zeros(2^k);
    bFtemp = zeros(2^k);

    for itemp=1:2^k
        for jtemp=1:2^k
            aFtemp(itemp,jtemp) = MULGF(alpha+1,F(itemp,jtemp)+1);
            bFtemp(itemp,jtemp) = MULGF(beta+1,F(itemp,jtemp)+1);
        end
    end
    F = [F zeros(2^k);aFtemp bFtemp];
end

%%  Transmission
c = -ones(1,N/r);
x = -ones(1,N);
Pc = zeros(N/r,q);  %ligne=signe et colonne PMF
u_decoded = zeros(1,N/r);
c_decoded = zeros(1,N/r);

Ifrozen = [];
error_count = zeros(1,N/r);

for tries=1:nbt
    u = randsrc(1,Ns,symb);
    u(Ifrozen+1) = zeros(1,numel(Ifrozen));

    for itemp=1:Ns
        S = 0;              %c=u*F
        for ktemp=1:Ns
            S = ADDGF(S+1,MULGF(u(ktemp)+1,F(ktemp,itemp)+1)+1);
        end
        c(itemp) = S;
    
        atemp = de2bi(S,r,'left-msb');  %Mapper
        x(r*(itemp-1)+1:r*itemp) = atemp;
    end

    xBPSK = -2*x +1;    %BPSK

    y = xBPSK + sigma2*randn(1,N);  %AWGN

    for itemp=1:Ns
        for jtemp=1:q
            Mul = 1;
            btemp = de2bi(jtemp-1,r,'left-msb');
            for ktemp=1:r
                Mul = Mul *(1 - Ptot(1-2*btemp(ktemp),y((itemp-1)*r+ktemp),sigma2));
            end
            Pc(itemp,jtemp) = Mul;      %proba de c_decoded
        end
    end
    
    %Pc = radicalized(Pc);
    c_decoded = node_decode_NB(log2(Ns),1,Pc,Ifrozen);
    

    for itemp=1:N/r
        S = 0;              %u=c*F
        for ktemp=1:N/r
            S = ADDGF(S+1,MULGF(c_decoded(ktemp)+1,F(ktemp,itemp)+1)+1);
        end
        u_decoded(itemp) = S;
    end

    error_count = error_count + (u_decoded~=u);

    percerror = 100*error_count/tries;
end

%%  Plotting
plot([-0.3 Ns-0.7],[100-100/q 100-100/q],'r');
hold on
plot((0:Ns - 1),percerror,'k.');

title('Symbol polarization - SNR=1db');
xlabel('symbol id');
ylabel('error (%)');
xlim([-0.3 Ns-0.7]);
ylim([-1 101]);
grid on
hold off

%saveas(gcf,'Spolar-l=10-r=2-SNR=-3_#?.png')