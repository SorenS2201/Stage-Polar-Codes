function [B] = radicalized(A)
B = zeros(size(A,1),size(A,2));

for i=1:size(A,1)   %pour chaque ligne
    [M I] = max(A(i,:));
    B(i,I) = 1;
end
end