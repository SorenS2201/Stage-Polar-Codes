%%
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sim Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SNR = [-17.0:0.25:-13.0];
SF = 7;
MC = 10000000;
TablePath='.\Tables\';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    LoRA Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = 2^SF;
Ts = 1;
Tc = Ts/M;
B = M/Ts;
symb = (0:M-1).';
BinaryTable = de2bi(symb,'left-msb');
n = (0:M-1);
dUpChirp = exp(1i*2*pi.*(n.^2/2/M-1/2.*n));
detectionMethod='coh';%'coh' or 'ncoh'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   LDPC Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Galois Field operations
    GF=M;
    ADDGF=load(strcat(TablePath,'ADDGF',int2str(GF)));
    DIVGF=load(strcat(TablePath,'DIVGF',int2str(GF)));
    MULGF=load(strcat(TablePath,'MULGF',int2str(GF)));
    BINGF=load(strcat(TablePath,'BINGF',int2str(GF)));
    %init parity check matrix
    %H=double(dvbs2ldpc(2/3));
    [ H ] = LoadMatPEG('LORAGF128RegR12N72');
    H=fliplr(flipud(H));
    [Mh, Nh] = size(H);
    Kh=Nh-Mh;
    Rate = Kh/Nh;%design rate
    %Tanner Graph Parameters reuired to decode
    NbVectorEdges=nnz(H);
    dv=unique(sum(H,1));
    dc=unique(sum(H.',1));
    dvClass=nonzeros(H*diag(sum(H,1)));
    dcClass=nonzeros(H'*diag(sum(H,2)));
    VNdegree=sum(H,1);
    Htmp=double(H');
    %index=find(Htmp~=0);
    Htmp(Htmp~=0)=(1:NbVectorEdges);
    Hintlv=nonzeros(Htmp');
   
    %Build NB matrix
    coeffs= randi([1 GF-1], NbVectorEdges, 1); %random coeeficient for now
    Htmp=double(H);
    index=find(Htmp~=0);
    Htmp(index)=coeffs;
    Hgf=Htmp;
    [col,row,v] = find(Hgf') ;
    %Build required Graph Permutation and interleavers 
    GFPerm=bi2de(BINGF,'left-msb')+1;
    [ExpPerm] = PermGFMessagesv2(GF,coeffs);%Permutation of VN messages when GF ordered
    GFtodec=bi2de(BINGF,'left-msb');
    DectoGF=(0:GF-1);
    DectoGF(GFPerm)=DectoGF;%Permutattion ok.
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SNRlin = 10.^(SNR./10);
Nb_ErrFrames_Max = 150;
EsN0 = zeros(1,length(SNR));
BERtot=zeros(1,numel(EsN0));
FERtot=zeros(1,numel(EsN0));
itermax=50;
taille=Nh;
CtoVintlv=1/GF*ones(GF,NbVectorEdges); %uniform a priori for check nodes messages
VtoCintlv=1/GF*ones(GF,NbVectorEdges); %uniform a priori for check nodes messages
%%%%%%%%%%%%%%%%%Start Sim%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for snr = 1:length(SNR)
    
        mc=0;
        FER=0;
        while ((FER<Nb_ErrFrames_Max)&&(mc<MC))
        %for mc = 1:MC
        mc=mc+1;
        
            %Symbols generation
            bits=randi([0 1],log2(GF),Kh);
            sg_msg = 1 - 2*bits;              % Sign-valued message  
            SymbDec=bi2de(bits','left-msb')';  
            
            %Encoding
            encodedSymb=encode_GF_LDPCv2(SymbDec,Nh,row,col,v,GF,GFtodec,BINGF,ADDGF,MULGF,DIVGF);
            [Status] = Compute_GF_Syndromev2(encodedSymb,Kh,row,col,v,GF,GFtodec,BINGF,ADDGF,MULGF,DIVGF);
            
            %No more interleaving required
            
            %symbol mapping
            %symboles = bi2de(encodedSymb,'left-msb');
            symboles_fsk = exp(1i*2*pi*encodedSymb/M).^n;
            signal = repmat(dUpChirp,taille,1).*symboles_fsk;
            
            % Canal Rayleigh
            Es = sum(sum((abs(signal).').^2))*Tc/taille;
            Ps = 1;
            N = Ps/SNRlin(snr);
            N0 = N/B;
            sig2 = N0*B;
            bruit = sqrt(sig2/2)*(randn(taille,M) + 1i*randn(taille,M));
%             pd = makedist('Rician','s',0,'sigma',1/sqrt(2));
%             A = random(pd,taille,1);
%             Theta = exp(1i*2*pi*rand(taille,1));
%             Hc = speye(taille);
%             Hc(Hc>0)=A.*Theta;
            %         H = diag(Theta);
            Hc = diag(ones(taille,1));
            signal_recu = Hc*signal + bruit;
            EsN0(snr) = Es/N0;
            
            % Reception
            y = diag(conj(dUpChirp))*signal_recu.'; 
            R = fft(y,M);
            R_norm = R/M;
            Sig2fft = M*sig2/2;
            
            %Compute A posteriori prob
            switch detectionMethod
                case 'coh'
                % Detecteur Coherent
                    Pyx = exp(2*sqrt(Es)*real(R_norm*conj(Hc))/N0);
                case 'ncoh'
                % Detecteur Non Coherent
                    Pyx = exp(Es/N0*abs(R_norm).^2/(Es + N0));
            end
            Pyx(Pyx>10^300) = 10^300;%handling numerical issues
            Normalization=speye(taille);
            Normalization(Normalization>0)=sum(Pyx);
            Pxy = Pyx*Normalization;
            
            % Iterative deocing loop
            %%%%%%%%%%%%%
            
            %allocations
            iter=0;
            Errors=+100;
            CtoVintlv=1/GF*ones(GF,NbVectorEdges); %uniform a priori for check nodes messages
            while((Errors ~= 0)&&(iter < itermax))
                
                %%VN Update
                [VtoC]=VNupdate_Proba(GF,Pxy,VNdegree,CtoVintlv,dvClass,NbVectorEdges);
        
                %%GF multiplication
                %to GF ordering
                VtoCintlv=VtoC(GFPerm,:);
                %GF permutations
                VtoCintlv(ExpPerm)=VtoCintlv(:);
                %back to Natural ordering
                VtoCintlv(GFPerm,:)=VtoCintlv;
                %graph interleaving
                VtoCintlv(:,Hintlv)=VtoCintlv;

                %%Check Node Update
                [CtoV]=FHT_CNUpdate(GF,VtoCintlv,dc,dcClass);
                %grpah deinterleaving
                CtoVintlv=CtoV(:,Hintlv);
        
                %%GF inv.  multiplication
                %to GF ordering
                CtoVintlv=CtoVintlv(GFPerm,:);
                %GF permutations
                CtoVintlv(:)=CtoVintlv(ExpPerm);
                %back to Natural ordering
                CtoVintlv(GFPerm,:)=CtoVintlv;
                [APP,EXT] = ComputeAPP(GF,Pxy,VNdegree,CtoVintlv,dvClass,NbVectorEdges);
                [~,Decisions]=max(APP);
                Decisions=Decisions-1;
                Errors=sum(Decisions(1:Kh)~=SymbDec);
                %[Status] = Compute_GF_Syndrome(Decisions,Hgf,GF,GFtodec,BINGF,ADDGF,MULGF,DIVGF);
                iter=iter+1;
                clc
                disp([mc,iter,Errors])
            end
            BERtot(snr)=BERtot(snr)+Errors;
            if Errors >0
            FERtot(snr)=FERtot(snr)+1;
            FER=FER+1;
            end
        end
        FERtot(snr)=FERtot(snr)/mc;
        BERtot(snr)=BERtot(snr)/mc/Kh;
        figure(1)
        clf;
        semilogy(SNR,FERtot,'ro-');
        hold on
        semilogy(SNR,BERtot,'bo-');
        grid on;
        axis([-18 -10  10^-6 1]);
        drawnow;
end
