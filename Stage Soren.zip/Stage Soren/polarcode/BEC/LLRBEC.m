function [z] = LLRBEC(y)
if (y==0)
    z = +10;
end
if (y==1)
    z = -10;
end
if (y==-1)  %effacé
    z = 0;
end
end