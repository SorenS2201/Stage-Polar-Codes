function [CodewordDec,CodewordBin] = encode_GF_LDPCv2(message,N,Hrows,Hcols,Hcoeffs,GF,GFtodec,BINGF,ADDGF,MULGF,DIVGF)
% Encoding for NB LDPC over Galois field of order GF=2^Q;
%   Encoding is done assuming directly encodable Parity CHeck Matrix
% 
%   Input parameters
%   ===============
%   -message: meassage in decimal using natural binary ordering (Left MSB);
%   -H: non binary PCMwith non binary coeff in gf order
%   -GF: Field Order
%   -GFtoDec: table for decimal correspondance for GF symbols ordererd in
%   the power domain
%   -BINGF: Binary representation of GF symbols, GF ordering
%   -ADDGF, MULGF and DIVGF: lookup table for GF operations, indexed using
%   power of prime element.

%Initialization
Q=log2(GF);
K=numel(message);
M=N-K;
%Encoding
GFPerm=bi2de(BINGF,'left-msb')+1;
DectoGF=(0:GF-1);
DectoGF(GFPerm)=DectoGF;
CodedSymb=zeros(1,N);
CodedSymb(1,1:K)=DectoGF(message+1);%Decimal to GF
ii=1;
for m=1:M
%     Coeffs=Hcoeffs(Hrows==m);
%     Symb=CodedSymb(Hcols(Hrows==m));
%     for k=1:numel(Symb)-1
%         CodedSymb(K+m)=ADDGF(CodedSymb(K+m)+1,MULGF(Coeffs(k)+1,Symb(k)+1)+1);
%     end
     while ((ii<(numel(Hrows)+1)) && (Hrows(ii)==(m)))
         if(Hcols(ii)<(m+K))
           CodedSymb(K+m)=ADDGF(CodedSymb(K+m)+1,MULGF(Hcoeffs(ii)+1,CodedSymb(Hcols(ii))+1)+1);
           %CodedSymb(Hrows(m)+K)=DIVGF(CodedSymb(K+m)+1,Coeffs(end)+1);
         else
             CodedSymb(m+K)=DIVGF(CodedSymb(K+m)+1,Hcoeffs(ii)+1);
         end
         ii=ii+1;  
     end
       
end
     CodewordDec=GFtodec(CodedSymb+1);
end

