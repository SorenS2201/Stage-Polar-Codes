clear;
clc;
global alpha beta ADDGF MULGF DIVGF GFPerm DectoGF

%%  Main variables
l = 10;
N = 2^l;
R = 0.5;    %rendement

AB = [1 1;
      3 1;
      6 2;
      14 2;
      26 2;
      38 1;
      105 1;
      204 2];

TablePath='Tables/';

Ifrozen = [];

Lr=[2];
LSNR_dB=(2:0.5:2);
nbt = 100;
error_count = zeros(numel(Lr),numel(LSNR_dB));

rtemp = 1;
for r=Lr
    snrtemp = 1;
    for SNR_dB=LSNR_dB
        SNR = 10^(SNR_dB/10);
        sigma2 = 1/(2*R*SNR);    %écart-type
        q = 2^r;
        
        alpha = AB(r,1);
        beta = AB(r,2);
        
        c = -ones(1,N/r);
        x = -ones(1,N);
        Pc = zeros(N/r,q);  %ligne=signe et colonne PMF
        u_decoded = zeros(1,N/r);
        c_decoded = zeros(1,N/r);

        %%  Galois Field operations
        GF=q;
        ADDGF=load(strcat(TablePath,'ADDGF',int2str(GF)));
        DIVGF=load(strcat(TablePath,'DIVGF',int2str(GF)));
        MULGF=load(strcat(TablePath,'MULGF',int2str(GF)));
        BINGF=load(strcat(TablePath,'BINGF',int2str(GF)));
        
        symb = (0:q-1);
        
        %%  Build required Graph Permutation and interleavers 
        GFPerm=bi2de(BINGF,'left-msb')+1;
        GFtodec=bi2de(BINGF,'left-msb');
        DectoGF=(0:GF-1);
        DectoGF(GFPerm)=DectoGF;%Permutattion ok.
        
        %%  Calcul de F
        F0 = [1 0;
              alpha beta];
        F = F0;
        
        for k=1:log2(N/r)-1
            aFtemp = zeros(2^k);
            bFtemp = zeros(2^k);
        
            for itemp=1:2^k
                for jtemp=1:2^k
                    aFtemp(itemp,jtemp) = MULGF(alpha+1,F(itemp,jtemp)+1);
                    bFtemp(itemp,jtemp) = MULGF(beta+1,F(itemp,jtemp)+1);
                end
            end
            F = [F zeros(2^k);aFtemp bFtemp];
        end
        
        %%  Transmission
        for tries=1:nbt
            u = randsrc(1,N/r,symb);
        
            for itemp=1:N/r
                S = 0;              %c=u*F
                for ktemp=1:N/r
                    S = ADDGF(S+1,MULGF(u(ktemp)+1,F(ktemp,itemp)+1)+1);
                end
                c(itemp) = S;
            
                atemp = de2bi(S,r,'left-msb');  %Mapper
                x(r*(itemp-1)+1:r*itemp) = atemp;
            end
        
            xBPSK = -2*x +1;    %BPSK
        
            y = xBPSK + sigma2*randn(1,N);  %AWGN
        
            %Demapper
            for itemp=1:N/r
                for jtemp=1:q
                    Mul = 1;
                    btemp = de2bi(jtemp-1,r,'left-msb');
                    for ktemp=1:r
                        Mul = Mul *(1 - Ptot(1-2*btemp(ktemp),y((itemp-1)*r+ktemp),sigma2));
                    end
                    Pc(itemp,jtemp) = Mul;      %proba de c_decoded
                end
            end
            
            %u_decoded = node_decode_NB(log2(N/r),1,Pc,Ifrozen);
        
            for itemp=1:N/r
                [ktemp,idxtemp] = sort(Pc(itemp,:));
                c_decoded(itemp) = idxtemp(q)-1;
            end
        
            error_count(rtemp,snrtemp) = error_count(rtemp,snrtemp) + sum(c_decoded~=c);
        end
        snrtemp = snrtemp + 1;
    end
    rtemp = rtemp + 1;
end

%%  Plotting
rtemp = 1;
for r=Lr
    semilogy(LSNR_dB,error_count(rtemp,:)/(nbt*N/r),'DisplayName',['r=' num2str(r)]);
    hold on
    rtemp = rtemp + 1;
end
title('HD - AWGN - NBPC');
xlabel('SNR (dB)');
ylabel('SER');
legend('Location','southwest');
grid on
hold off
%saveas(gcf,'HD-AWGN-NBPC_#2.png')