function [U] = node_decode(etage,etape,L,Ifrozen)
%disp([etage,etape]);
if etage==0 %on a leaf
    if ismember(etape,Ifrozen)
        U = 0;
    elseif L>0
        U = 0;
    else
        U = 1;
    end

else        %on any other node
    n = size(L,2);
    L2 = f(L(1:n/2),L(n/2 +1:n));
    U2 = node_decode(etage-1,2*(etape-1)+1,L2,Ifrozen);    %on active la node de gauche

    L3 = g(L(1:n/2),L(n/2 +1:n),U2);
    U3 = node_decode(etage-1,2*(etape-1)+2,L3,Ifrozen);    %on active la node de droite

    U = rem([U2+U3 U3],2);
end
end