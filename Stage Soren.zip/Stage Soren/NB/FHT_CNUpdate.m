function [CtoV] = FHT_CNUpdate(GF,VtoCintlv,dc,dcClass)
%UNTITLED Summary of this function goes here
%   VtoCintlv: CN perspective reordered messages
%   dvClass: the vector containing the dv type of the incoming messages
CtoV=zeros(GF,numel(VtoCintlv)/GF);%initialization of local CtoV messages
%Transfom domain
VtoCFFT=fwht(VtoCintlv,GF,'hadamard');%Projecting Vector Probability messages into the Hadamard Domain;
%Note Hadamard ordering implies binary ordering of probability messages;
%Ordering in the transform domain does not matter here

    for jj=dc%vectorization of FHT CN update is possible only per dc degree
        %vectorized product for all CNs of same degree in the transform
        %domain
        VtoCFFTtmp=reshape(VtoCFFT(:,dcClass==jj),GF,jj,numel(dcClass(dcClass==jj))/jj);
        %Loop is need since incoming messages can be zero
        CtoVFFTtmp=zeros(GF,jj,numel(dcClass(dcClass==jj))/jj);
            for kk=1:jj
                CtoVFFTtmp(:,kk,:)=prod(VtoCFFTtmp(:,(1:jj)~=kk,:),[2]);%product of all incoming messges to avoid 'if' condition
            end
        CtoVFFTtmp=reshape(CtoVFFTtmp(:),GF,numel(CtoVFFTtmp)/GF);
        CtoV(:,dcClass==jj)=ifwht(CtoVFFTtmp,GF,'hadamard');%back to the probability domain, mulitplication by GF is here to cope with normalized messag    
    end
 NormValues=1./sum(CtoV);
 NormMat=speye(numel(NormValues),numel(NormValues));
 NormMat(NormMat~=0)=NormValues;
 CtoV=CtoV*NormMat;%normalization
end

