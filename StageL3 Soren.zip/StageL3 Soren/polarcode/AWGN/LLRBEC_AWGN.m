function [z] = LLRBEC_AWGN(y,sigma2)
z = (2/sigma2)*y;
end